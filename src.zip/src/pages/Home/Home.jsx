import "./Home.css";

const Home = () => {
	return (
		<div className="home">
			{/* HERO SECTION */}
			<section className="hero">
				<div className="hero-content">
					<h1>Breathe Better. Look Better. Live Better.</h1>
					<p>
						VO₂ Skin & Hair Clinic delivers advanced
						oxygen-based therapies for skin rejuvenation, hair
						restoration, weight management, and complete
						wellness.
					</p>

					<div className="hero-buttons">
						<button className="btn-primary">
							Make Appointment
						</button>
						<button className="btn-secondary">
							Explore Oxygen Therapies
						</button>
					</div>
				</div>
			</section>

			{/* OXYGEN PHILOSOPHY */}
			<section className="oxygen-philosophy">
				<h2>The Power of Oxygen Therapy</h2>
				<p>
					Oxygen is essential for healthy skin, strong hair, and
					efficient fat metabolism. At VO₂ Clinic, we use
					controlled oxygen infusion technologies to stimulate
					cell regeneration, detoxification, and deep
					nourishment—naturally and safely.
				</p>

				<div className="oxygen-features">
					<div className="feature-card">
						<h3>🫁 Deep Oxygenation</h3>
						<p>Boosts circulation and cellular renewal</p>
					</div>
					<div className="feature-card">
						<h3>🌿 Cell Regeneration</h3>
						<p>Supports healing and collagen production</p>
					</div>
					<div className="feature-card">
						<h3>✨ Instant Glow</h3>
						<p>Improves skin texture and radiance</p>
					</div>
					<div className="feature-card">
						<h3>🧠 Stress Relief</h3>
						<p>Promotes relaxation and detox</p>
					</div>
				</div>
			</section>

			{/* SERVICES */}
			<section className="services">
				<h2>Our Signature Oxygen Treatments</h2>

				<div className="service-cards">
					<div className="service-card">
						<h3>Oxygen Facial Therapy</h3>
						<p>
							Hydrates, brightens, and rejuvenates skin
							naturally.
						</p>
					</div>

					<div className="service-card">
						<h3>Oxygen Hair & Scalp Therapy</h3>
						<p>
							Improves scalp health and supports hair
							growth.
						</p>
					</div>

					<div className="service-card">
						<h3>Oxygen Slimming Therapy</h3>
						<p>
							Activates fat metabolism and body contouring.
						</p>
					</div>

					<div className="service-card">
						<h3>Laser Assisted Oxygen Treatments</h3>
						<p>
							Faster healing and enhanced treatment
							results.
						</p>
					</div>
				</div>
			</section>

			{/* WHY CHOOSE US */}
			<section className="why-choose">
				<h2>Why Choose VO₂ Clinic?</h2>

				<ul>
					<li>✔️ Advanced oxygen-based technology</li>
					<li>✔️ Expert dermatologists & therapists</li>
					<li>✔️ Personalized treatment plans</li>
					<li>✔️ Medical-grade hygiene standards</li>
					<li>✔️ Proven results for skin, hair & body</li>
				</ul>
			</section>

			{/* CTA */}
			<section className="cta">
				<h2>Take a Deep Breath. Begin Your Transformation.</h2>
				<button className="btn-primary">Book Appointment</button>
			</section>
		</div>
	);
};

export default Home;
